// import React from 'react';
// import { Col, Row, Container} from 'react'
// import '../../styles/Form-side-bar.css'

// const FormSideBar = () => {
//     return (
        
//              <div className="hero-form">
//      <Container> 
//       <Row className="form-row">
//         <Col lg="4" md="4">
//           <div className="find-cars-left">
//             <h2>Find your best car here</h2>
//           </div>
//         </Col>

       
//       </Row>
//     </Container>
//   </div> 
        
//     );
// }

// export default FormSideBar;