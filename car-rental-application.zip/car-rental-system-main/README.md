# car-rental-system
``` npm start ``` for car rental 

```  nodemon index.js  ``` for backend
